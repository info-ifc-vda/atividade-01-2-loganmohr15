import java.util.Arrays;

 

public class MatrizVetores {

    public static void main(String[] args) {

        int[][] matriz = new int[7][7];

 

        // Preenche a matriz com números inteiros aleatórios (exemplo)

        for (int i = 0; i < 7; i++) {

            for (int j = 0; j < 7; j++) {

                matriz[i][j] = (int) (Math.random() * 100); // Números de 0 a 99

            }

        }

 

        // Vetores para armazenar os maiores elementos das linhas e menores elementos das colunas

        int[] maioresLinhas = new int[7];

        int[] menoresColunas = new int[7];

 

        // Encontra os maiores elementos das linhas e menores elementos das colunas

        for (int i = 0; i < 7; i++) {

            maioresLinhas[i] = encontrarMaior(matriz[i]);

        }

 

        for (int j = 0; j < 7; j++) {

            int[] coluna = new int[7];

            for (int i = 0; i < 7; i++) {

                coluna[i] = matriz[i][j];

            }

            menoresColunas[j] = encontrarMenor(coluna);

        }

 

        // Imprime a matriz e os vetores

        System.out.println("Matriz:");

        for (int i = 0; i < 7; i++) {

            System.out.println(Arrays.toString(matriz[i]));

        }

 

        System.out.println("Maiores elementos das linhas: " + Arrays.toString(maioresLinhas));

        System.out.println("Menores elementos das colunas: " + Arrays.toString(menoresColunas));

    }

 

    // Função para encontrar o maior elemento em um vetor

    public static int encontrarMaior(int[] vetor) {

        int maior = vetor[0];

        for (int elemento : vetor) {

            if (elemento > maior) {

                maior = elemento;

            }

        }

        return maior;

    }

 

    // Função para encontrar o menor elemento em um vetor

    public static int encontrarMenor(int[] vetor) {

        int menor = vetor[0];

        for (int elemento : vetor) {

            if (elemento < menor) {

                menor = elemento;

            }

        }

        return menor;

    }

}

