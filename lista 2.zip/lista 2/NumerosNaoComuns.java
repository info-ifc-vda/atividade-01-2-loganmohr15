import java.util.Arrays;

 

public class NumerosNaoComuns {

    public static void main(String[] args) {

        int[] vetor1 = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };

        int[] vetor2 = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };

 

        int tamanhoVetorResultado = vetor1.length + vetor2.length;

        int[] vetorResultado = new int[tamanhoVetorResultado];

        int indiceResultado = 0;

 

        for (int elemento : vetor1) {

            if (!contains(vetor2, elemento)) {

                vetorResultado[indiceResultado] = elemento;

                indiceResultado++;

            }

        }

 

        for (int elemento : vetor2) {

            if (!contains(vetor1, elemento)) {

                vetorResultado[indiceResultado] = elemento;

                indiceResultado++;

            }

        }

 

        // Redimensiona o vetor resultado para o tamanho correto

        vetorResultado = Arrays.copyOf(vetorResultado, indiceResultado);

 

        System.out.println("Números não comuns entre os vetores:");

        System.out.println(Arrays.toString(vetorResultado));

    }

 

    // Verifica se um elemento está presente no vetor

    public static boolean contains(int[] vetor, int elemento) {

        for (int num : vetor) {

            if (num == elemento) {

                return true;

            }

        }

        return false;

    }

}

 