import java.util.Scanner;

 

public class TabelaValores {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        int contadorLinhas = 0;

 

        System.out.println("Digite os valores (0 ou negativo para encerrar):");

        System.out.println("------------------------------------------------");

 

        System.out.printf("%-10s %-10s %-15s%n", "Valor", "Cubo", "Raiz Quadrada");

        System.out.println("----------------------------------------------");

 

        while (true) {

            System.out.print("Digite um valor: ");

            double valor = scanner.nextDouble();

 

            if (valor <= 0) {

                break;

            }

 

            double cubo = Math.pow(valor, 3);

            double raizQuadrada = Math.sqrt(valor);

 

            System.out.printf("%-10.2f %-10.2f %-15.2f%n", valor, cubo, raizQuadrada);

 

            contadorLinhas++;

            if (contadorLinhas % 20 == 0) {

                System.out.println("Pressione Enter para continuar...");

                scanner.nextLine(); // Aguarda a tecla Enter

            }

        }

 

        System.out.println("Programa encerrado. Obrigado!");

        scanner.close();

    }

}

 