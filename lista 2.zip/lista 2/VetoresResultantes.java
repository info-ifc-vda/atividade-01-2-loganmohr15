import java.util.Arrays;

 

public class VetoresResultantes {

    public static void main(String[] args) {

        int[] vetor1 = { 2, 4, 6, 8, 10, 12, 14, 16, 18, 20 };

        int[] vetor2 = { 3, 5, 7, 9, 11 };

 

        int tamanhoVetorResultado = vetor1.length;

        int[] primeiroVetorResultado = new int[tamanhoVetorResultado];

        int[] segundoVetorResultado = new int[tamanhoVetorResultado];

 

        // Calcula o primeiro vetor resultante

        for (int i = 0; i < tamanhoVetorResultado; i++) {

            primeiroVetorResultado[i] = vetor1[i] + somaVetor(vetor2);

        }

 

        // Calcula o segundo vetor resultante

        for (int i = 0; i < tamanhoVetorResultado; i++) {

            if (vetor1[i] % 2 != 0) {

                segundoVetorResultado[i] = contarDivisores(vetor1[i], vetor2);

            }

        }

 

        System.out.println("Primeiro vetor resultante: " + Arrays.toString(primeiroVetorResultado));

        System.out.println("Segundo vetor resultante: " + Arrays.toString(segundoVetorResultado));

    }

 

    // Função para somar todos os elementos de um vetor

    public static int somaVetor(int[] vetor) {

        int soma = 0;

        for (int elemento : vetor) {

            soma += elemento;

        }

        return soma;

    }

 

    // Função para contar divisores de um número em outro vetor

    public static int contarDivisores(int numero, int[] vetor) {

        int contador = 0;

        for (int elemento : vetor) {

            if (elemento != 0 && numero % elemento == 0) {

                contador++;

            }

        }

        return contador;

    }

}

 